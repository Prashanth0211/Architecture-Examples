package com.cg.studentdemo.exception;

public class StudentException {

}
