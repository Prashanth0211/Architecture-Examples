package com.cg.studentdemo.exception;

public interface IStudentExceptionMessages {

}
