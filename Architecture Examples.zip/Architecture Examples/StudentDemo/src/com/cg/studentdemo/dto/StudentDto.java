package com.cg.studentdemo.dto;

import java.time.LocalDate;

public class StudentDto {

	private int stuId;
	private String stuName;
	private LocalDate dob;
	private int passOut;

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public int getPassOut() {
		return passOut;
	}

	public void setPassOut(int passOut) {
		this.passOut = passOut;
	}

}
