package com.cg.studentdemo.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Scanner;

import com.cg.studentdemo.dto.StudentDto;
import com.cg.studentdemo.service.IStudentService;
import com.cg.studentdemo.service.StudentServiceImpl;

public class MyMain {

	public static void main(String[] args) {

		IStudentService service = new StudentServiceImpl();

		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Student Name:");
				String sname = scr.next();
				DateTimeFormatter formate = DateTimeFormatter.ofPattern("MMM-dd-yyyy");
				System.out.println("Enter the Dob in mmm-dd-yyyy");
				String date = scr.next();
				LocalDate myDate = LocalDate.parse(date, formate);

				System.out.println("Enter Passout Year:");
				int pyear = scr.nextInt();

				StudentDto dto = new StudentDto();

				dto.setStuName(sname);
				dto.setDob(myDate);
				dto.setPassOut(pyear);
				service.addStudent(dto);
				break;

			case 2:
				HashSet<StudentDto> allData = service.showAllDetails();
				for (StudentDto all : allData) {

					System.out.println("Student Id is: " + all.getStuId());
					System.out.println("Student Name is:" + all.getStuName());
					DateTimeFormatter formatee = DateTimeFormatter.ofPattern("MMM-dd-yyyy");
					System.out.println("Student dob is: " + all.getDob().format(formatee));
					System.out.println("Student PassOut Year is: " + all.getPassOut());
				}
				break;

			case 3:
				System.out.println("Enter Student Id ");
				int prodId = scr.nextInt();
				StudentDto studentSearch = service.searchStudent(prodId);
				System.out.println("Student Id is: " + studentSearch.getStuId());
				System.out.println("Student Name is:" + studentSearch.getStuName());
				System.out.println("Student dob is: " + studentSearch.getDob());
				System.out.println("Student PassOut Year is: " + studentSearch.getPassOut());

				break;
			case 4:
				System.out.println("Enter Student Id ");
				int rid = scr.nextInt();
				service.removeStudent(rid);
				break;
			case 5:
				System.out.println("Enter Student Id: ");
				int uid=scr.nextInt();
				System.out.println("Enter Name");
				String uname=scr.next();
				System.out.println("Enter Year");
				int uyear=scr.nextInt();
				
				StudentDto update=new StudentDto();
				update.setStuId(uid);
				update.setStuName(uname);
				update.setPassOut(uyear);
				service.updateStudent(update);
				break;
			default:
				System.exit(0);
				
			}
		} while (choice != 6);
	}

	public static void printDetails() {

		System.out.println("1.Add Student ");
		System.out.println("2.Show All Students ");
		System.out.println("3.Search Student ");
		System.out.println("4.Remove Student");
		System.out.println("5.Update Student");
        System.out.println("6.Exit");
	}
}
