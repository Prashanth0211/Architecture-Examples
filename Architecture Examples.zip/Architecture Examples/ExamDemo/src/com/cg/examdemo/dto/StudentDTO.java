package com.cg.examdemo.dto;

public class StudentDTO {

}
