package com.cg.examdemo.exception;

public class StudentException {

}
