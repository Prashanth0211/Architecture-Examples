package com.cg.examdemo.exception;

public interface IStudentExceptionMessages {

}
