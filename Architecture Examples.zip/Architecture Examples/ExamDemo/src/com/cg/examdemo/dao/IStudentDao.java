package com.cg.examdemo.dao;

public interface IStudentDao {

}
