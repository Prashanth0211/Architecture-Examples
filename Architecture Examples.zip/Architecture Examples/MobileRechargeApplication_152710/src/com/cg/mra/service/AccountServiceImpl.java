package com.cg.mra.service;

import java.util.HashMap;

import com.cg.mra.bean.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.AccountExceptionMessgae;

public class AccountServiceImpl implements AccountService {

	AccountDao dao = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public boolean rechargeAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return dao.rechargeAccount(mobileno, rechargeAmount);
	}

	@Override
	public boolean validateNumber(String num) throws AccountException {
		if (!(num.matches("[0-9]+"))) {
			throw new AccountException(AccountExceptionMessgae.ERROR);
		}
		return true;
	}

	@Override
	public HashMap<String, Account> viewDetails(String id) {
		// TODO Auto-generated method stub
		return dao.viewDetails(id);
	}

}
