package com.cg.mra.dao;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class AccountDaoImplTest {

	private static AccountService service = null;

	@BeforeClass
	public static void setUpBeforeClass() throws AccountException {
		service = new AccountServiceImpl();
	}

	@Test
	public void testIdWhenInput() {
		HashMap<String, Account> dto = service.viewDetails("1234");
		assertNotNull(dto);
	}

}
