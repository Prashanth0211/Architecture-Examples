package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.bean.Account;

public class AccountDaoImpl implements AccountDao {

	private static HashMap<String, Account> hashmap = null;
	static {
		hashmap = new HashMap<>();
		Account cus1 = new Account();
		cus1.setMobileNo("7660824282");
		cus1.setAccountType("Postpaid");
		cus1.setCustomerName("Prashanth");
		cus1.setAccountBalance(500.00);

		Account cus2 = new Account();
		cus2.setMobileNo("9441742260");
		cus2.setAccountType("Postpaid");
		cus2.setCustomerName("Shivaram");
		cus2.setAccountBalance(300.00);

		hashmap.put("7660824282", cus1);
		hashmap.put("9441742260", cus2);
	}

	@Override
	public Account getAccountDetails(String mobileNo) {

		return hashmap.get(mobileNo);
	}

	@Override
	public boolean rechargeAccount(String mobileno, double rechargeAmount) {
		boolean result = false;
		if (hashmap.containsKey(mobileno)) {
			Account dto = new Account();

			String cusName = hashmap.get(mobileno).getCustomerName();
			double balance = hashmap.get(mobileno).getAccountBalance();
			dto.setMobileNo(mobileno);
			dto.setCustomerName(cusName);
			dto.setAccountBalance(balance + rechargeAmount);

			hashmap.remove(mobileno);
			hashmap.put(mobileno, dto);

			result = true;
		}
		return result;
	}

	@Override
	public HashMap<String,Account> viewDetails(String id) {
		// TODO Auto-generated method stub
		return hashmap;
	}

}
