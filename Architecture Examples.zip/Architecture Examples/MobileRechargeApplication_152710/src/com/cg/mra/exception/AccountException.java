package com.cg.mra.exception;

public class AccountException extends Exception {

	public AccountException() {
		super();
	}

	public AccountException(String msg) {
		super(msg);
	}
}
