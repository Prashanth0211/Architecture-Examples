package com.cg.studentproject.exception;

public class StudentException extends Exception{

	public StudentException() {
		// TODO Auto-generated constructor stub
	}
	public StudentException(String arg)
	{
		super(arg);
	}

}
