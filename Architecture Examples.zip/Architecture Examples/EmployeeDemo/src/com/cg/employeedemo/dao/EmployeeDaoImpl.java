package com.cg.employeedemo.dao;

import java.util.ArrayList;
import com.cg.employeedemo.dto.EmployeeDto;
import com.cg.employeedemo.staticdb.EmployeeDataBase;


public class EmployeeDaoImpl implements IEmployeeDao {
	
	@Override
	public ArrayList<EmployeeDto> getAllEmployeeDetails() {
		
		return EmployeeDataBase.getAllEmployeeDetails();
	}

	@Override
	public EmployeeDto getUniqueDetails(int eid) {
		
		for(EmployeeDto dt:EmployeeDataBase.getAllEmployeeDetails() ) {
			if(eid==dt.getEmpId()) {
				return dt;
			}
			
		}
		return null;
	}

	@Override
	public void addEmployeeDetails(EmployeeDto dto) {
		EmployeeDataBase.addEmployeeDetails(dto);
		
	}

	@Override
	public void modifySalary(int empid, double sal) {
		
		
		
	}

	
	

}
