package com.cg.employeedemo.service;

import java.util.ArrayList;

import com.cg.employeedemo.dto.EmployeeDto;

public interface IEmployeeService {

	public ArrayList<EmployeeDto> getAllEmployeeDetails();
	public EmployeeDto getUniqueDetails(int eid);
	public void addEmployeeDetails(EmployeeDto dto);
	public void modifySalary(int empid,double sal);
}
