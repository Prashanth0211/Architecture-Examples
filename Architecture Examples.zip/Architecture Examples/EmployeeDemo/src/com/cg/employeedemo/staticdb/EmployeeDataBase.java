package com.cg.employeedemo.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeedemo.dto.EmployeeDto;

public class EmployeeDataBase {

	private static ArrayList<EmployeeDto> myList=null;
	static {
		myList=new ArrayList<>();
	}
	
	public static ArrayList<EmployeeDto> getAllEmployeeDetails(){
		
		EmployeeDto emp1=new EmployeeDto();
		emp1.setEmpId(1001);
		emp1.setEmpName("Prashanth");
		emp1.setEmpSalary(9999.22);
		emp1.setEmpDesignation("Analyst");
		
		EmployeeDto emp2=new EmployeeDto();
		emp2.setEmpId(1002);
		emp2.setEmpName("Nihal");
		emp2.setEmpSalary(9555.22);
		emp2.setEmpDesignation("Analyst");
		
		EmployeeDto emp3=new EmployeeDto();
		emp3.setEmpId(1003);
		emp3.setEmpName("Rithish");
		emp3.setEmpSalary(9556.22);
		emp3.setEmpDesignation("Analyst");
		
		EmployeeDto emp4=new EmployeeDto();
		emp4.setEmpId(1003);
		emp4.setEmpName("Pavan");
		emp4.setEmpSalary(9566.22);
		emp4.setEmpDesignation("Analyst");
		
		myList.add(emp1);
		myList.add(emp2);
		myList.add(emp3);
		myList.add(emp4);
		
		
		return myList;
		
	}
	public static void addEmployeeDetails(EmployeeDto dto) {
		myList.add(dto);
	}
}
