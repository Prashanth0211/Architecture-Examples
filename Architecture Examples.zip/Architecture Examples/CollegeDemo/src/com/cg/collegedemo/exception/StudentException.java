package com.cg.collegedemo.exception;

public class StudentException extends Exception {

	public StudentException() {
		super();
	}

	public StudentException(String msg) {
		super(msg);
	}
}
