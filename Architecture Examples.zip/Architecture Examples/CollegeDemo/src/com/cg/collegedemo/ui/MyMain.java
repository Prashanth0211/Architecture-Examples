package com.cg.collegedemo.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import com.cg.collegedemo.dto.StudentDto;
import com.cg.collegedemo.exception.IStudentExceptionMessages;
import com.cg.collegedemo.exception.StudentException;
import com.cg.collegedemo.service.IStudentService;
import com.cg.collegedemo.service.StudentServiceImpl;

public class MyMain {

	public static void main(String[] args) {
		int choice = 0;
		IStudentService service = new StudentServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Name");
				String name = scr.next();
				System.out.println("Enter PhoneNumber");
				String num = scr.next();
				System.out.println("Enter email");
				String mail = scr.next();
				System.out.println("Enter Age");
				int age = scr.nextInt();
				System.out.println("Enter Gender");
				String gen = scr.next();
				System.out.println("Enter City");
				String city = scr.next();
				System.out.println("Enter the Doj in dd-MMM-yyyy");
				String date = scr.next();
				try {
					DateTimeFormatter formate = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					LocalDate myDate = LocalDate.parse(date, formate);
					StudentDto dto = new StudentDto();
					dto.setStudName(name);
					dto.setStuPhone(num);
					dto.setStuEmail(mail);
					dto.setStuAge(age);
					dto.setStuGen(gen);
					dto.setStuCity(city);
					dto.setDoj(myDate);
					boolean result = false;
					try {
						result = service.validationDetails(dto);
					} catch (StudentException stException) {
						System.out.println(stException.getMessage());
					}
					if (result) {
						service.addStudentDetails(dto);
						System.out.println("Id is: " + dto.getStuId());
					}
				} catch (DateTimeParseException exception) {
					try {
						throw new StudentException(IStudentExceptionMessages.MESSAGE5);
					} catch (StudentException e) {
						System.out.println(e.getMessage());
					}
				}
				break;
			case 2:
				System.out.println("Enter Id to view");
				int sid = scr.nextInt();
				StudentDto dt = service.viewStudentStatus(sid);
				if (dt != null) {
					System.out.println("Student Name: " + dt.getStudName());
					System.out.println("Status: " + dt.getStuStatus());
					System.out.println("Student College: " + dt.getStuCollege());
				} else {
					System.out.println("Student Not Found");
				}
				break;
			default:
				System.exit(0);
				break;
			}
		} while (choice != 4);

	}

	public static void printDetails() {
		System.out.println("MENU");
		System.out.println("1.Add Student Details");
		System.out.println("2.View Student Status");
		System.out.println("3.Exit");
	}
}
